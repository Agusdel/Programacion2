#include <iostream>
#include <fstream>
#include <string>

using namespace std;

const int CANTIDAD_MALETINES = 9;

int main()
{
    bool reiniciar;
    do{
        reiniciar = true;

        string nombreArchivo = "nombreArchivo.txt";
        char* archivoDatos = (char*)nombreArchivo.c_str();

        string mejorJugador;
        int mejorPuntaje;
        CargarMejorPuntaje(archivoDatos, mejorJugador, mejorPuntaje);

        MensajeInicial(); //Mostrar nombre del jugador con mejor puntaje.
        string nombre;
        SolicitarNombre(nombre);

        int maletines [CANTIDAD_MALETINES];

        CargarMaletines(maletines, archivoDatos);

        int maletinPrincipal = ElegirMaletin(maletines);

        int premio = Juego(maletines, maletinPrincipal);

        GuardarDatos(nombre, premio, archivoDatos);

        Reiniciar(reiniciar);
    } while(reiniciar);
}

int Juego(int maletines[], int maletinPrincipal){
    int cantidadAElegir = 3;
    while(ALGO ACA){
        for (short i = 0; i < cantidadAElegir; i++){
            ElegirMaletin(maletines);
        }
        HacerOferta();
        cantidadAElegir--;
    }
}


void GuardarDatos(string nombre, int premio, char nombreArchivo[]){

    ofstream archivoDatos (nombreArchivo, ios::app);

    archivoDatos << nombre << ","  << premio << endl;
}

void CargarMejorPuntaje(char archivoDatos[], string &mejorJugador, int &mejorPuntaje){

}
